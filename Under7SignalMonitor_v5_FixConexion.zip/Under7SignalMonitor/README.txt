Under 7 Signal Monitor v5 - Fix de conexion
- Agrega permiso INTERNET al AndroidManifest.
- Corrige el mapeo de ticks_history usando req_id; la API nueva ya no garantiza echo_req.
- Usa subscribe:0 para historial y una suscripcion ticks por simbolo.
- Mantiene 5 indices 1s y ventanas 100/500/1000.
- Este proyecto se compila con el workflow de GitHub Actions existente.
