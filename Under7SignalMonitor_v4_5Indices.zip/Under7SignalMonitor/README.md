# Under 7 Signal Monitor v2

Monitor Android para analizar ticks de índices sintéticos y calcular Under 7 en ventanas móviles de 100, 500 y 1000 ticks.

Incluye workflow de GitHub Actions para compilar `app-debug.apk` sin PC.

**Importante:** la app es un monitor estadístico; no ejecuta operaciones ni garantiza resultados futuros.
