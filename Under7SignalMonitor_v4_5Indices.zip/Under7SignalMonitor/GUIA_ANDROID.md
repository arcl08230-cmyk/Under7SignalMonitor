# Cómo obtener el APK usando SOLO Android

Este proyecto está preparado para que GitHub compile el APK por vos. No necesitás PC ni Android Studio.

## 1. Crear una cuenta de GitHub

Desde Chrome en tu Android entra a https://github.com/ y crea/inicia sesión.

## 2. Crear un repositorio

En GitHub toca **+** → **New repository**.

Nombre sugerido: `Under7SignalMonitor`.

Déjalo como **Public** para simplificar el uso de GitHub Actions. No contiene claves ni contraseñas.

Toca **Create repository**.

## 3. Subir este proyecto

Descomprime el ZIP en tu teléfono. Debes subir el CONTENIDO de la carpeta `Under7SignalMonitor`, no crear una carpeta adicional `Under7SignalMonitor/Under7SignalMonitor`.

En el repositorio toca **Add file** → **Upload files** y selecciona todos los archivos y carpetas del proyecto.

Luego toca **Commit changes**.

## 4. Ejecutar la compilación

En el repositorio abre **Actions**.

Selecciona **Build APK**.

Toca **Run workflow** → **Run workflow**.

GitHub compilará el proyecto en sus servidores. El workflow usa Gradle y genera un APK debug.

## 5. Descargar el APK

Cuando el trabajo termine en verde, abre la ejecución terminada.

En la sección **Artifacts** toca `Under7SignalMonitor-debug`.

Se descargará un ZIP. Ábrelo y extrae `app-debug.apk`.

## 6. Instalar en Android

Toca `app-debug.apk`.

Si Android muestra un aviso sobre instalar aplicaciones desconocidas, permite esa instalación para el navegador/gestor de archivos que estés usando y vuelve a abrir el APK.

Después toca **Instalar**.

## Qué hace la app

- Analiza dígitos de índices sintéticos mediante ticks.
- Mantiene ventanas móviles reales de 100, 500 y 1000 ticks.
- Calcula Under 7 como dígitos 0–6.
- Puede mostrar una señal cuando se alcanza el umbral configurado.
- La señal es informativa y no ejecuta operaciones.

## Si GitHub muestra un error

Entra a **Actions** → la ejecución fallida → abre el paso que aparece en rojo y copia el mensaje de error. Con ese mensaje se puede corregir el proyecto.
