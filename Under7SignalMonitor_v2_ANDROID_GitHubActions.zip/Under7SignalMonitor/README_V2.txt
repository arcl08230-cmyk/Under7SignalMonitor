UNDER 7 SIGNAL MONITOR v2

Esta versión usa ventanas móviles reales:
- Últimos 100 ticks
- Últimos 500 ticks
- Últimos 1000 ticks

Cada tick nuevo entra al buffer y, cuando hay más de 1000, se elimina el tick más antiguo.
La señal aparece cuando cualquiera de las tres ventanas tiene >= 75% de dígitos Under 7 (0-6).

La app solo analiza y alerta; no ejecuta operaciones.
Los datos de mercado públicos de Deriv se reciben por WebSocket sin autenticación.
